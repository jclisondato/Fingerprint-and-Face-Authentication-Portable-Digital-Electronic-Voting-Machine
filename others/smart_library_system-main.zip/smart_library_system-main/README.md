# smart_library_system
for more information go to given link:-
https://youtu.be/BSsYHDe9wwY
