# Face-Recognition-Haar-LBPH
A project that implements traditional face detection using Haar Cascades, and face recognition using LBPH Face Recognizer.
