# pyqt5_camera_viewer
In this example, we demonstrate how to create simple camera viewer using Opencv3 and PyQt5.

If you  need to change ui_main_window.ui with QtDesigner, don't forget to regenerate ui_main_window.py file using this command:  
```{r, engine='sh', count_lines}
pyuic5 main_window.ui -o main_window.py
```



